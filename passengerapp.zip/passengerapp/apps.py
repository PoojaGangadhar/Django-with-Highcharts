from django.apps import AppConfig


class PassengerappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'passengerapp'
